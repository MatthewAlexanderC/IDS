# DWH Coding Challenge Solution

## Overview

This project processes event logs to reconstruct historical tables for `accounts`, `cards`, and `saving_accounts`. It then joins these tables and analyzes transactions that impact account balances or card credit usage.

## Running the Solution

### Prerequisites

- Docker
- Python 3.9 (if you want to run the script locally)
- `pandas` library

### Steps

1. Place your JSON event logs in the `data/` directory.
2. If running locally:
   1. Create and activate a virtual environment:
      ```sh
      python -m venv venv
      source venv/bin/activate  # For Windows: venv\Scripts\activate
      ```
   2. Install dependencies:
      ```sh
      pip install pandas
      ```
   3. Run the script:
      ```sh
      python solution/main.py
      ```
3. If running in Docker:
   1. Build the Docker image:
      ```sh
      cd solution
      docker build -t dwh-coding-challenge .
      ```
   2. Run the Docker container:
      ```sh
      docker run --rm -v $(pwd)/../data:/app/data dwh-coding-challenge
      ```

### Output

The script will print:
1. Historical tables for `accounts`, `cards`, and `saving_accounts`.
2. The joined table.
3. Transactions affecting balances and credit usage.
