import pandas as pd
import json
import os

# Fungsi untuk memproses log peristiwa dari sebuah direktori
def process_event_logs(direktori):
    records = []
    for subdir, _, files in os.walk(direktori):
        for filename in files:
            if filename.endswith(".json"):
                file_path = os.path.join(subdir, filename)
                with open(file_path, 'r') as file:
                    try:
                        events = json.load(file)
                        for event in events:
                            if event['op'] == 'c':
                                record = event['data']
                                record['ts'] = event['ts']
                                records.append(record)
                            elif event['op'] == 'u':
                                for record in records:
                                    if record['id'] == event['id']:
                                        record.update(event['set'])
                                        record['ts'] = event['ts']
                    except json.JSONDecodeError:
                        print(f"Error decoding JSON from file: {file_path}")
    return pd.DataFrame(records)

# Memuat dan memproses log peristiwa
accounts = process_event_logs('data/accounts')
cards = process_event_logs('data/cards')
saving_accounts = process_event_logs('data/saving_accounts')

# Menampilkan tabel historis
print("Tabel Akun:")
print(accounts)
print("\nTabel Kartu:")
print(cards)
print("\nTabel Tabungan:")
print(saving_accounts)

# Mengasumsikan kunci gabungan adalah sama di semua tabel dan menggunakan 'id' untuk contoh ini
# Menggabungkan tabel
joined_table = accounts.merge(cards, on='id', how='left', suffixes=('_account', '_card')).merge(saving_accounts, on='id', how='left', suffixes=('', '_savings'))
print("\nTabel Gabungan:")
print(joined_table)

# Menganalisis transaksi
# Mengasumsikan bahwa bidang 'balance' dan 'credit_used' ada dalam rekaman
transactions = joined_table[
    (joined_table['balance'].diff() != 0) | 
    (joined_table['credit_used'].diff() != 0)
]

print("\nTransaksi:")
print(transactions[['id', 'ts', 'balance', 'credit_used']])